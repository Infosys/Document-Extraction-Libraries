# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from abc import ABC, abstractmethod
from typing import List

from ..data import ProcessorResponseData, DocumentData


class IOrchestratorNative(ABC):
    """Orchestrator interface for native execution of processors"""
    @abstractmethod
    def run_batch(self, document_data_list: List[DocumentData] = None,
                  context_data_list: List[dict] = None) -> List[ProcessorResponseData]:
        """Run the pipeline"""
        raise NotImplementedError("run not implemented")

    @abstractmethod
    def pre_run_hook(self, processor_instance: object, config_data: dict,
                     processor_response_data_list: List[ProcessorResponseData]) -> (object, List[ProcessorResponseData]):
        """ Pre run hook for the processor """
        raise NotImplementedError("pre_run_hook not implemented")

    @abstractmethod
    def post_run_hook(self, processor_instance: object, config_data: dict,
                      processor_response_data_list: List[ProcessorResponseData],
                      new_processor_response_data_list: List[ProcessorResponseData]) -> List[ProcessorResponseData]:
        """ Post run hook for the processor """
        raise NotImplementedError("post_run_hook not implemented")
