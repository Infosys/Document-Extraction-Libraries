# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for Vector Db provider interface"""

import abc
from typing import List
from ...embedding.interface.i_embedding_provider import IEmbeddingProvider
from ...schema.vector_db_data import BaseVectorDbQueryParamsData, BaseVectorDbRecordData


class IVectorDbProvider(metaclass=abc.ABCMeta):
    """Interface class for Vector Db provider"""

    def __init__(self, db_type: str, embedding_provider: IEmbeddingProvider) -> None:
        self.__db_type = db_type
        # Set embedding provider at class level for child classes to access
        self._embedding_provider = embedding_provider

    def get_db_type(self):
        """Returns database type `db_type`"""
        return self.__db_type

    @abc.abstractmethod
    def get_matches(self, query_params_data: BaseVectorDbQueryParamsData) -> List[BaseVectorDbRecordData]:
        """Returns matches for given `query` from vector Db"""
        raise NotImplementedError

    @abc.abstractmethod
    def save_record(self, db_record_data: BaseVectorDbRecordData):
        """Saves a record to vector Db"""
        raise NotImplementedError

    @abc.abstractmethod
    def get_records(self, count: int = -1) -> List[BaseVectorDbRecordData]:
        """Get all records from vector dB"""
        raise NotImplementedError

    @abc.abstractmethod
    def delete_records(self):
        """Delete specific records from vector dB"""
        raise NotImplementedError

    @abc.abstractmethod
    def get_custom_metadata(self):
        """Return custom metadata schema"""
        raise NotImplementedError
