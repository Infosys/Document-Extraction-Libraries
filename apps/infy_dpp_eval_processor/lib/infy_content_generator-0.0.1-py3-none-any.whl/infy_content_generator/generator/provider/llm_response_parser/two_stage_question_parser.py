# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for two stage question response parser provider class"""
import re
from ...interface.i_llm_response_parser_provider import ILLMResponseParserProvider


class TwoStageQuestionResParserProvider(ILLMResponseParserProvider):
    """Class for two stage question response parser provider"""

    def __init__(self):
        pass

    def parse_llm_response(self, llm_response_txt, input_que_type: dict, context: str) -> dict:
        """Parse the LLM response and return a questions_data """
        questions = re.split(r'Q\d+:', llm_response_txt)[1:]  # Skip the first empty element
        questions_data = {'question': [], 'type': [], 'answer_source': []}

        for q in questions:
            # Extract question text
            question = q.strip().split('Type:')[0].strip()

            # Extract type
            type_match = re.search(r'Type:\s*(\w+)', q)
            q_type = type_match.group(1) if type_match else None

            # Extract context support
            # support_match = re.search(
            # r'Support:\s*(.*?)(?=Q\d+:|$)', q, re.DOTALL)
            # support = support_match.group(1).strip() if support_match else None

            # Only add to result if none of the elements are None
            if question and q_type:
                questions_data['question'].append(question)
                questions_data['type'].append(q_type)
                # questions_data['answer_source'].append(support)

        questions_data['answer_source'].extend([context] * len(questions_data['question']))
        return questions_data
