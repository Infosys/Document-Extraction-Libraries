# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 1.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may score in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#
"""
This class is the implementation for the process layer
"""

from .interface import IQnaStrategyProvider
from ..data.qna_data import QnaResponseData


class QnaGenerator():
    """Class for generation of questions and answers"""

    def __init__(self, qna_strategy_provider: IQnaStrategyProvider) -> None:
        self.__qna_strategy_provider = qna_strategy_provider

    def generate_qna(self, context_list: list[str], metadata: dict = None) -> QnaResponseData:
        """Generate qna for provided text."""

        qna_response_data = self.__qna_strategy_provider.generate_qna(
            context_list, metadata)

        return qna_response_data
