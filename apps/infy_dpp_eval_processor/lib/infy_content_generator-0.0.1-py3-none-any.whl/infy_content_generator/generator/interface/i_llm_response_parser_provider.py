# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for embedding provider interface class"""

import abc
from ...data.qna_data import QnaResponseData


class ILLMResponseParserProvider(metaclass=abc.ABCMeta):
    """Interface class for question answer generation provider"""
    @abc.abstractmethod
    def parse_llm_response(self, llm_response_txt, input_que_type: dict, context: str) -> QnaResponseData:
        """Parse the LLM response"""
        raise NotImplementedError
