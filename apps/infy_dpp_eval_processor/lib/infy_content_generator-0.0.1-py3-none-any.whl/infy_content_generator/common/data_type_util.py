# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for Data Type Util class"""


class DataTypeUtil():
    """Util class for util methods to process common data types"""

    @classmethod
    def get_by_key_path(cls, data_dict: dict, key_path: str, raise_error=False):
        """Get value from a dictionary using keypath"""
        key_path_token_list = key_path.split(".")
        _data_dict = data_dict
        key_path_token_found_list = []
        for key_path_token in key_path_token_list:
            if key_path_token in _data_dict:
                key_path_token_found_list.append(key_path_token)
                _data_dict = _data_dict[key_path_token]
                if not _data_dict:
                    break
        found_key_path = ".".join(key_path_token_found_list)
        if not key_path == found_key_path:
            if raise_error:
                message = f"Keypath not found!: Requested keypath = '{key_path}' | Found keypath: '{found_key_path}'"
                raise ValueError(message)
            return None
        return _data_dict
