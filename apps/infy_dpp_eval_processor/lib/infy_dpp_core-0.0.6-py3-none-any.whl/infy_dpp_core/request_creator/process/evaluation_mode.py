# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#
import os
import infy_dpp_sdk
import infy_fs_utils
from ...common.file_util import FileUtil


class EvaluationMode:
    def __init__(self, PROCESSEOR_CONTEXT_DATA_NAME):
        self.__logger = infy_fs_utils.manager.FileSystemLoggingManager().get_fs_logging_handler(
            infy_dpp_sdk.common.Constants.FSLH_DPP).get_logger()
        self.__app_config = infy_dpp_sdk.common.AppConfigManager().get_app_config()
        self.__file_sys_handler = infy_fs_utils.manager.FileSystemManager(
        ).get_fs_handler(infy_dpp_sdk.common.Constants.FSH_DPP)
        self.PROCESSEOR_CONTEXT_DATA_NAME = PROCESSEOR_CONTEXT_DATA_NAME

    def get_evaluation_mode_dir_created(self, input_doc, from_data_file_config):
        def __get_temp_file_path(work_file_path):
            local_file_path = f'{self.__app_config["CONTAINER"]["APP_DIR_TEMP_PATH"]}/{work_file_path}'
            FileUtil.create_dirs_if_absent(os.path.dirname(local_file_path))
            with self.__file_sys_handler.get_file_object(work_file_path) as f:
                with open(local_file_path, "wb") as output:
                    output.write(f.read())
            return local_file_path

        response_list = []
        work_root_path = from_data_file_config.get('work_root_path')
        documend_id = FileUtil.get_uuid()
        doc_dir_name = f"D-{documend_id}"
        self.__logger.info("Processing file %s", input_doc)

        # ---- Create file paths -----
        work_file = FileUtil.safe_file_path(
            f"{work_root_path}/{doc_dir_name}/{os.path.basename(input_doc)}")
        supporting_files = FileUtil.safe_file_path(
            f"{work_file}_files/")
        # storage_uri = FileUtil.safe_file_path(self.__file_sys_handler.get_storage_uri().split("://")[1])
        storage_uri = FileUtil.safe_file_path(
            self.__file_sys_handler.get_storage_root_uri().split("://")[1])
        temp_input_doc = FileUtil.safe_file_path(
            input_doc).replace(storage_uri, '')

        # ---- Create supporting files folder -----
        self.__file_sys_handler.create_folders(
            supporting_files)

        # ---- Copy input file to work folder -----
        self.__file_sys_handler.copy_file(
            temp_input_doc, work_file)

        from_files_full_path = __get_temp_file_path(
            work_file)
        out_file_full_path = f'{from_files_full_path}_files'
        # _, extension = os.path.splitext(
        #     from_files_full_path)
        if not os.path.exists(out_file_full_path):
            os.makedirs(out_file_full_path)
        # ---- Create response data -----
        metadata = infy_dpp_sdk.data.MetaData(
            standard_data=infy_dpp_sdk.data.StandardData(
                filepath=infy_dpp_sdk.data.ValueData(value=input_doc)))
        document_data = infy_dpp_sdk.data.DocumentData(
            document_id=documend_id, metadata=metadata)
        context_data = {
            self.PROCESSEOR_CONTEXT_DATA_NAME: {
                "work_file_path": work_file
            }
        }
        message_data = infy_dpp_sdk.data.MessageData()
        response_data = infy_dpp_sdk.data.ProcessorResponseData(
            document_data=document_data, context_data=context_data)
        response_list.append(response_data)

        return response_list
