# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import json
import requests


class IndexIdHandlerService:

    def __init__(self) -> None:
        pass

    def post_index_id(self, indexer_response: dict, endpoint: str, payload: dict, headers: dict):
        index_id, index_name = '', ''
        if indexer_response:
            for index_type, index_data in indexer_response.items():
                if index_type == 'vector_db':
                    index_id = index_data.get('index_id', '')
                    break
                elif index_type == 'sparse_index':
                    index_id = index_data.get('index_id', '')
                    break
        if index_id:
            index_name = index_id.split('-', 1)[0]
        if index_id and index_name:
            payload['indexId'] = index_id
            payload['indexName'] = index_name
            try:
                response = requests.post(
                    endpoint, json=payload, headers=headers, timeout=30)
                if response.status_code == 200:
                    api_response = response.json()
                    if api_response.get('status') == 'Success' and api_response.get('data').get('status') == 'Created':
                        return True
                    else:
                        return False
                else:
                    raise RuntimeError("Failed to call endpoint")
            except requests.RequestException as e:
                raise RuntimeError(f"Failed to call endpoint: {e}") from e
        else:
            raise ValueError("Index ID or Index Name is missing")
