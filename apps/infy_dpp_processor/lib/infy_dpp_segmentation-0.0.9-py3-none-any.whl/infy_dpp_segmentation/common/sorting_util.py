# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for Image Sort Util class"""

import re
import os


class ImageSortUtil():
    """Util class for sorting image files"""

    @staticmethod
    def atoi(text):
        return int(text) if text.isdigit() else text

    @staticmethod
    def natural_keys(text):
        basename = os.path.basename(text)
        match = re.match(r'^(\d+)', basename)
        if match:
            return (int(match.group(1)), basename)
        else:
            return (float('inf'), basename)

    @classmethod
    def sort_image_files(cls, img_file_path_list):
        return sorted(img_file_path_list, key=cls.natural_keys)
