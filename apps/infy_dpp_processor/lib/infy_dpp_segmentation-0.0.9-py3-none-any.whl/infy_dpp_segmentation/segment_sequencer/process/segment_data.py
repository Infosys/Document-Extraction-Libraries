# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import copy
from infy_dpp_segmentation.segment_sequencer.common.common_util import CommonUtil
from infy_dpp_segmentation.segment_sequencer.rules.rule_segment_base_class import RuleSegmentBaseClass


class SegementData:
    def __init__(self, file_sys_handler, logger, app_config) -> None:
        self.__logger = logger
        self.__app_config = app_config
        self.__file_sys_handler = file_sys_handler

    def update_sequence(self, segment_data_list, layout, pattern, pages, page):
        is_content_bbox_empty = False
        for segment_data in segment_data_list:
            if not segment_data.get("content_bbox"):
                is_content_bbox_empty = True
        if (layout == 'single-column' and pattern == 'sequence-order') or is_content_bbox_empty:
            rule_name = 'rule_segment_default'
            rule_class = CommonUtil.get_rule_class_instance(
                rule_name, rc_entity_name='')
            rule_instance: RuleSegmentBaseClass = rule_class(
                self.__file_sys_handler, self.__logger, self.__app_config)
            rule_result = rule_instance.template_method(
                copy.deepcopy(segment_data_list), pages, page)
        # if  layout =='single' and pattern == 'default'
        elif layout == 'multi-column' and pattern == 'left-right':
            rule_name = 'rule_segment_left_to_right'
            rule_class = CommonUtil.get_rule_class_instance(
                rule_name, rc_entity_name='')
            rule_instance: RuleSegmentBaseClass = rule_class(
                self.__file_sys_handler, self.__logger, self.__app_config)
            rule_result = rule_instance.template_method(
                copy.deepcopy(segment_data_list), pages, page)
        elif layout == 'multi-column' and pattern == 'zig-zag':
            rule_name = 'rule_segment_zig_zag'
            rule_class = CommonUtil.get_rule_class_instance(
                rule_name, rc_entity_name='')
            rule_instance: RuleSegmentBaseClass = rule_class(
                self.__file_sys_handler, self.__logger, self.__app_config)
            rule_result = rule_instance.template_method(
                copy.deepcopy(segment_data_list), pages, page)
        else:
            raise Exception('Invalid layout and pattern.')
        return rule_result
