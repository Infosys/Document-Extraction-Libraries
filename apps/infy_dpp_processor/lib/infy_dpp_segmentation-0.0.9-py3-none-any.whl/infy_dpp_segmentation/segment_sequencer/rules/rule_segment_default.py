# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from infy_dpp_segmentation.segment_sequencer.rules.rule_segment_base_class import RuleSegmentBaseClass
from infy_dpp_segmentation.common.file_util import FileUtil


class RuleSegmentDefault(RuleSegmentBaseClass):
    def __init__(self, file_sys_handler, logger, app_config) -> None:
        super().__init__()
        self.__file_sys_handler = file_sys_handler
        self.__app_config = app_config
        self.__logger = logger

    def generate_sequence_no(self, segment_data_list: list, pages, page) -> list:
        # Filter segments to include only those from the target page
        segment_data_list = [
            segment for segment in segment_data_list if segment['page'] == page]

        updated_segment_data_list = []
        counter = 1
        for segment_data in segment_data_list:
            # TODO: segment logic should be added.
            # if len(segment_data.get('content_bbox')) > 0:
            #     pass
            # else:
            single_segment_data_dict = segment_data
            single_segment_data_dict.update({"sequence": counter,
                                            "segment_id": f'S-{FileUtil.get_uuid()[:5]}'})
            updated_segment_data_list.append(single_segment_data_dict)
            counter = counter+1
        return updated_segment_data_list
