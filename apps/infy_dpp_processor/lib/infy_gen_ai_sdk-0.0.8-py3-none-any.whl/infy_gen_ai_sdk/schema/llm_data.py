# ===============================================================================================================#
# (C) 2022 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from typing import List
import uuid
try:
    from pydantic.v1 import BaseModel
except ImportError:
    from pydantic import BaseModel


class BaseLlmRequestData(BaseModel):
    """Base class for request to LLM"""
    # request_id: str = None
    prompt_template: str = None
    template_var_to_value_dict: dict = None


class BaseLlmResponseData(BaseModel):
    """Base class for response from LLM"""
    llm_request_txt: str = None
    llm_response_txt: str = None
    status_code : str = None
    status_message : str = None   


class BaseLlmResponseList(BaseModel):
    """Base class for batch response from LLM"""
    responses: List = [BaseLlmResponseData]
