# ===============================================================================================================#
# (C) 2022 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from typing import Optional
try:
    from pydantic.v1 import BaseModel
except ImportError:
    from pydantic import BaseModel


class BaseVectorDbRecordData(BaseModel):
    """Base class for embedding provider config data"""
    id: str = None
    content: str = None
    metadata: dict = None


class BaseVectorDbQueryParamsData(BaseModel):
    """Base class for storing query params for Vector DB search"""
    query: str = None
    filter_metadata: dict = None
    top_k: int   # Max number of matching records to return
    # Number of documents to fetch before filtering.
    pre_filter_fetch_k: int


class OnlineVectorDbConfigData(BaseModel):
    """Base class for online provider config data"""
    db_service_url: str = None
    model_name: str = None
    index_id: Optional[str] = None
    collection_name: str = None
    collection_secret_key: str = None
