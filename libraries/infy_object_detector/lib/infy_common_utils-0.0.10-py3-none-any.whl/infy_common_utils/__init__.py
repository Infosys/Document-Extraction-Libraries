# ===============================================================================================================#
# (C) 2020 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""## 1. Introduction

`infy_common_utils` is a python library to provide commonly used horizontal APIs.

It's also a python wrapper for the following non-python libraries:

- infy-format-converter.jar


## 2. Version History

- **V 0.0.2** _(2021-08-03)_
  - Removed jar file embeded in wheel file. Caller needs to provide the jar file home path.
  - APIs exposed are `PdfToImg`.

- **V 0.0.1** _(2021-07-05)_
  - Initial version as a python wrapper for `infy-format-converter.jar.
  - APIs exposed are `PdfToJson` and `PdfToText`.


## 3. Prerequisite

The following software should be installed in your local system.

- Python 3.6
- infy-format-converter.jar
"""
