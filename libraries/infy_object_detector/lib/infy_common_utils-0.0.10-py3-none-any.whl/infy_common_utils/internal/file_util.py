# ===============================================================================================================#
# (C) 2020 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import os
import json
import copy
import shutil
from os import path


class FileUtil:
    "Util class for file activities"
    @staticmethod
    def create_dirs_if_absent(dir_name):
        '''
        Creates directories recursively if it doesn't exist.
        The dir_name can be relative or absolute

        Parameters:
            dir_name (string): Relative or absolute path of the directory
        '''
        dir_path = dir_name
        try:
            if not path.isabs(dir_path):
                dir_path = path.abspath(dir_path)
            if not path.isdir(dir_path):
                os.makedirs(dir_path)
        except:
            pass

        return dir_path

    @staticmethod
    def remove_files(file_list):
        """Remove files"""
        for file in file_list:
            os.remove(file)

    @staticmethod
    def save_to_json(out_file, data):
        """Save json files"""
        is_saved, error = True, None
        try:
            with open(out_file, "w") as f:
                json.dump(data, f, indent=4)
        except Exception as ex:
            is_saved, error = False, ex.args[0]
        return is_saved, error

    @staticmethod
    def get_updated_config_dict(from_dict, default_dict):
        """compare input config and update missing default keys"""
        config_dict_temp = copy.deepcopy(default_dict)
        for key in from_dict:
            if isinstance(from_dict[key], dict):
                config_dict_temp[key] = FileUtil.get_updated_config_dict(
                    from_dict[key], config_dict_temp[key])
            else:
                config_dict_temp[key] = from_dict[key]
        return config_dict_temp

    @staticmethod
    def move(src, dst):
        """Method to move file"""
        shutil.move(src, dst)

    @staticmethod
    def copy(src, dst):
        """Mathod to copy file"""
        shutil.copy(src, dst)
