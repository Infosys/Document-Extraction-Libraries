# ===============================================================================================================#
# (C) 2020 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

class StatisticUtil:
    """Class to find statistics"""
    @classmethod
    def get_confidence_score(cls, hocr_line_prediction, img_line_prediction):
        """Get confidence score"""
        row_pos_len_list = [len(img_line_prediction['rows']),
                            len(hocr_line_prediction['rows'])]
        col_pos_len_list = [len(img_line_prediction['cols']),
                            len(hocr_line_prediction['cols'])]
        row_score = round(min(row_pos_len_list)/max(row_pos_len_list), 2)
        col_score = round(min(col_pos_len_list)/max(col_pos_len_list), 2)
        return row_score, col_score
