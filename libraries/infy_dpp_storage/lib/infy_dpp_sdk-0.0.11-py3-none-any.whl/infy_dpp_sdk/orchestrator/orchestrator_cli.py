# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from ._internal.b_orchestrator import BOrchestrator
from ._operator.cli_operator import CLIOperator


class OrchestratorCLI(BOrchestrator):
    """Orchestrator that invokes processors using CLI."""

    def execute_processor(self, processor_input_config_data: dict,
                          processor_deployment_config_data: dict,
                          orchestrator_config_data: dict) -> dict:
        """
        Execute a processor.

        Args:
            processor_input_config_data (dict): Input configuration data for the processor.
            processor_deployment_config_data (dict): Deployment configuration data for the processor.
            orchestrator_config_data (dict): Configuration data for the orchestrator.

        Returns:
            dict: Result of the processor execution.
        """
        return CLIOperator().execute_processor(processor_deployment_config_data)
