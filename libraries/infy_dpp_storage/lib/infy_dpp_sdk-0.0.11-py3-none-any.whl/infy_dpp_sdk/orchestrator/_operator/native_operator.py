# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#


import json
import logging
import importlib
import traceback
import infy_fs_utils
from ...interface import IProcessor
from ...data import (ControllerRequestData, ControllerResponseData)
from ...common import Constants
from ...common._internal.snapshot_util import SnapshotUtil
from ...common._internal.processor_helper import ProcessorHelper


class NativeOperator():
    """Orchestrator for native calls"""

    def __init__(self) -> None:
        self.__fs_handler = infy_fs_utils.manager.FileSystemManager(
        ).get_fs_handler(Constants.FSH_DPP)
        if infy_fs_utils.manager.FileSystemLoggingManager().has_fs_logging_handler(Constants.FSLH_DPP):
            self.__logger = infy_fs_utils.manager.FileSystemLoggingManager(
            ).get_fs_logging_handler(Constants.FSLH_DPP).get_logger()
        else:
            self.__logger = logging.getLogger(__name__)

    def execute_processor(self, processor_deployment_config_data: dict,
                          processor_input_config_data: dict):
        """Execute a processor"""

        new_output_variables_dict = {}
        try:

            # ------------ Auto import the processors ------------------
            library = importlib.import_module(
                processor_input_config_data['processor_namespace'])
            my_processor_obj: IProcessor = getattr(
                library, processor_input_config_data['processor_class_name'])()
            my_processor_obj.set_proc_name(
                processor_input_config_data['processor_name'])

            # ------------ Read the controller request file ------------------
            controller_request_file_path = processor_deployment_config_data.get('args', {}).get(
                'request_file_path', None)
            if controller_request_file_path:
                controller_request_file_data = json.loads(self.__fs_handler.read_file(
                    controller_request_file_path))
                input_config_file_data = json.loads(self.__fs_handler.read_file(
                    controller_request_file_data['input_config_file_path']))
            else:
                raise ValueError(
                    'controller_request_file_path is required')

            # # ------------ Filter the config data ------------------
            # filtered_config_data = {}
            # for processor_input_config_name in processor_input_config_data.get(
            #         'processor_input_config_name_list', []):
            #     filtered_config_data[processor_input_config_name] = input_config_file_data.get(
            #         'processor_input_config').get(processor_input_config_name)

            controller_request_data: ControllerRequestData = ControllerRequestData(
                **controller_request_file_data)
            snapshot_util = SnapshotUtil()
            document_data_list, context_data_list, _ = snapshot_util.load_snapshots(
                controller_request_data)
            config_data = processor_input_config_data.get(
                'processor_input_config', {})

            # # ------------ Read document data and context data list ----------
            # snapshot_dir_root_path = controller_request_file_data['snapshot_dir_root_path'] + "/"
            # document_data_file_path_list = [
            #     snapshot_dir_root_path +
            #     x['snapshot']['document_data_file_path'] for x in controller_request_file_data['records']]
            # document_data_list = [DocumentData(**json.loads(self.__fs_handler.read_file(
            #     x))) for x in document_data_file_path_list]
            # context_data_file_path_list = [
            #     snapshot_dir_root_path +
            #     x['snapshot']['context_data_file_path'] for x in controller_request_file_data['records']]
            # context_data_list = [json.loads(self.__fs_handler.read_file(
            #     x)) for x in context_data_file_path_list]

            # ------------ Call the processor ------------------
            try:
                new_processor_response_list = my_processor_obj.do_execute_batch(
                    document_data_list, context_data_list, config_data)
            except Exception as ex:
                full_trace_error = traceback.format_exc()
                self.__logger.error(full_trace_error)
                new_processor_response_list = []
                for document_data, context_data in zip(document_data_list, context_data_list):
                    _processor_response_data = ProcessorHelper.create_processor_response_data(
                        document_data, context_data, ex)
                    new_processor_response_list.append(
                        _processor_response_data)

            controller_response_data: ControllerResponseData = snapshot_util.save_snapshots(
                controller_request_data, new_processor_response_list)

            dpp_controller_res_file_path = snapshot_util.save_controller_response_data(
                controller_response_data)

            output_variables_dict = processor_deployment_config_data['output']['variables']

            if output_variables_dict:
                for output_variable, _ in output_variables_dict.items():
                    new_output_variables_dict[output_variable] = dpp_controller_res_file_path

        except Exception as ex:
            raise Exception(ex) from ex
        return new_output_variables_dict
