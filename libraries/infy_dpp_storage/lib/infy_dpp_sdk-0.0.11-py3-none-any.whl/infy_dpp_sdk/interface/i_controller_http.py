# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from abc import ABC, abstractmethod
from typing import Union
from typing_extensions import Annotated
try:
    import fastapi
except ImportError:
    # This is optional component only required for implementing HTTP controller
    # Create a pseudo class to avoid ImportError
    class fastapi():
        """Pseudo class"""
        class Request():
            """Pseudo class"""

        class Header():
            """Pseudo class"""
from ..data import (ControllerRequestData, ControllerResponseData)


class IControllerHTTP(ABC):
    """Interface for executing processor(s) when orchestrator makes HTTP API calls."""

    @abstractmethod
    def receive_and_respond(self, controller_request_data: ControllerRequestData,
                            request: fastapi.Request,
                            DPP_STORAGE_ROOT_URI: Annotated[Union[str, None],
                                                            fastapi.Header()] = None,
                            DPP_STORAGE_SERVER_URL: Annotated[Union[str, None],
                                                              fastapi.Header()] = None,
                            DPP_STORAGE_ACCESS_KEY: Annotated[Union[str, None],
                                                              fastapi.Header()] = None,
                            DPP_STORAGE_SECRET_KEY: Annotated[Union[str, None],
                                                              fastapi.Header()] = None,
                            ) -> ControllerResponseData:
        """Receive the request, do processing and send response"""
        raise NotImplementedError
