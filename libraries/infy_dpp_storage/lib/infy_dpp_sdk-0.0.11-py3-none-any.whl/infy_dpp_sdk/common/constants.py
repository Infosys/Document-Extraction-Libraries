# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module containing Constants class"""
import importlib.metadata


class Constants():
    """Constants class"""
    FSH_DPP = 'dpp-fsh'
    FSLH_DPP = 'dpp-fslh'

    # ----- Private Constants ----- #
    try:
        _DPP_VERSION = importlib.metadata.version('infy_dpp_sdk')
    except importlib.metadata.PackageNotFoundError:
        _DPP_VERSION = "0.0.0"
    _ORCHESTRATOR_ROOT_PATH = '/data/temp/work/dpp_orchestrator'
    _ORCHESTRATOR_SNAPSHOT_PATH = _ORCHESTRATOR_ROOT_PATH + '/snapshots'
    _SYS_CONTROLLER_REQ_FILE_PATH = "SYS_CONTROLLER_REQ_FILE_PATH"
    _SYS_CONTROLLER_RES_FILE_PATH = "SYS_CONTROLLER_RES_FILE_PATH"
    _CONTROLLER_REQUEST_FILE_NAME_SUFFIX = "_dpp_controller_request.json"
    _CONTROLLER_RESPONSE_FILE_NAME_SUFFIX = "_dpp_controller_response.json"
    _SYS_ENV_VAR_DPP_STORAGE_ROOT_URI = "DPP_STORAGE_ROOT_URI"
    _SYS_ENV_VAR_DPP_STORAGE_SERVER_URL = "DPP_STORAGE_SERVER_URL"
    _SYS_ENV_VAR_DPP_STORAGE_ACCESS_KEY = "DPP_STORAGE_ACCESS_KEY"
    _SYS_ENV_VAR_DPP_STORAGE_SECRET_KEY = "DPP_STORAGE_SECRET_KEY"
    _FILE_NAME_DOCUMENT_DATA = "document_data.json"
    _FILE_NAME_CONTEXT_DATA = "context_data.json"
    _FILE_NAME_MESSAGE_DATA = "message_data.json"
