# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for PydanticUtil class"""

import pydantic


class PydanticUtil():
    """Util class for handling pydantic version specific methods"""

    @classmethod
    def get_json_str(cls, obj: any, indent=0) -> str:
        """
        Get json string from pydantic object.

        Args:
            obj (any): Pydantic object.
            indent (int, optional): Indentation level for the JSON string. Defaults to 0.

        Returns:
            str: JSON string representation of the pydantic object.
        """
        if pydantic.VERSION.startswith('1.'):
            data_json = obj.json(indent=indent)
        else:
            data_json = obj.model_dump_json(indent=4)
        return data_json
