# ===============================================================================================================#
# (C) 2021 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#


import os
import copy
import logging

try:
    import win32com.client as win32c
except ImportError:
    pass
from infy_ocr_generator.interface.data_service_provider_interface import (
    GENERATE_API_RES_STRUCTURE, DataServiceProviderInterface, DOC_DATA)

CONFIG_PARAMS_DICT = {
    'abbyy': {
        'customer_project_Id': '',
        'license_path': '',
        'license_password': ''
    }
}


class AbbyyOcrDataServiceProvider(DataServiceProviderInterface):
    """Implementation of DataServiceProvider for ABBYY"""

    def __init__(self, config_params_dict: CONFIG_PARAMS_DICT,
                 output_dir: str = None,
                 output_to_supporting_folder: bool = False,
                 overwrite: bool = False,
                 logger: logging.Logger = None,
                 log_level: int = None):
        """Creates an instance of Abbyy Ocr Data Service Provider

        Args:
            config_params_dict (CONFIG_PARAMS_DICT): Provider CONFIG values
            output_dir(str, optional): Directory to generate OCR file,
                if not given will generate into same file location. Defaults to None.
            output_to_supporting_folder(bool, optional): If True, OCR file will be generated to
                same file location but into supporting folder named `* _files`. Defaults to False.
            overwrite(bool, optional): If True, existing OCR file will be overwritten. Defaults to False.
            logger (logging.Logger, optional): logger object. Defaults to None.
            log_level (int, optional): log level. Defaults to None.
        """
        super(AbbyyOcrDataServiceProvider, self).__init__(logger, log_level)
        self.config_params_dict = self.get_updated_config_dict(
            config_params_dict['abbyy'], CONFIG_PARAMS_DICT['abbyy'])
        if output_dir and not os.path.exists(output_dir):
            raise FileNotFoundError(f"{output_dir} not found")
        self.output_dir = output_dir
        self.output_to_supporting_folder = output_to_supporting_folder
        self.overwrite = overwrite

    def submit_request(self,  doc_data_list: [DOC_DATA]) -> list:
        raise NotImplementedError

    def receive_response(self, submit_req_response_list: list, rerun_unsucceeded_mode: bool = False) -> list:
        raise NotImplementedError

    def generate(self,  doc_data_list: [DOC_DATA] = None, api_response_list: list = None) -> list:
        def _call_abbyy_sdk_engine(in_doc_obj):
            gen_res_dict = copy.deepcopy(GENERATE_API_RES_STRUCTURE)
            in_doc = in_doc_obj['doc_path']
            gen_res_dict['input_doc'] = in_doc
            try:
                pages = in_doc_obj['pages']
                final_out_ocr_path = self.get_output_file(
                    in_doc, self.output_dir, self.output_to_supporting_folder,
                    suffix='.xml', pages=pages)
                gen_res_dict['output_doc'] = final_out_ocr_path
                if not self.overwrite and os.path.exists(final_out_ocr_path):
                    return gen_res_dict

                engine_loader = None
                engine = None
                document = None
                self.logger.info("Load engine..")
                engine_loader = win32c.Dispatch("FREngine.OutprocLoader.12")
                engine = engine_loader.InitializeEngine(
                    self.config_params_dict["customer_project_Id"],
                    self.config_params_dict["license_path"],
                    self.config_params_dict["license_password"], "", "", False)

                self.logger.info("Loading predefined profile...")
                engine.LoadPredefinedProfile("DocumentConversion_Accuracy")
                document = engine.CreateFRDocument()
                self.logger.info("Loading input files...")
                document.AddImageFile(in_doc, None, None)
                self.logger.info("Process...")
                document.Process(None)

                self.logger.info("Saving results...")
                FEF_XML = 7
                XMParams = engine.CreateXMLExportParams()
                XMParams.WriteCharAttributes = 3

                document.Export(final_out_ocr_path, FEF_XML, XMParams)
            except Exception as e:
                gen_res_dict['error'] = e.args[0]
                self.logger.error(e)
            finally:
                self.logger.info("Close document...")
                if document:
                    document.Close()
                self.logger.info("Unload ABBYY FineReader Engine..")
                engine = None
                engine_loader.ExplicitlyUnload()
                engine_loader = None
            return gen_res_dict
        if len(doc_data_list) == 0:
            raise Exception("Valid doc_data_list arg is required.")
        ocr_list = []
        for in_doc_obj in doc_data_list:
            ocr_list.append(_call_abbyy_sdk_engine(in_doc_obj))
        return ocr_list
