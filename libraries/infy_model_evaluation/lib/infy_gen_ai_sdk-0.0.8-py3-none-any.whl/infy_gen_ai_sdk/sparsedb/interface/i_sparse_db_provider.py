# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for Sparse Db provider interface"""

import abc
from ...schema.sparse_db_data import BaseSparseDbConfigData, BaseSparseDbSaveRecordData, BaseSparseDbQueryParamsData


class ISparseDbProvider(metaclass=abc.ABCMeta):
    """Interface class for Sparse Db provider"""

    def __init__(self, config_data: BaseSparseDbConfigData) -> None:
        """Saves a record to sparse Db"""
        raise NotImplementedError

    @abc.abstractmethod
    def save_record(self, sparse_record_config_dict: BaseSparseDbSaveRecordData):
        """Saves a record to sparse Db"""
        raise NotImplementedError

    @abc.abstractmethod
    def get_records(self):
        """get specific records from sparse dB"""
        raise NotImplementedError
    
    @abc.abstractmethod
    def get_matches(self, query_params_data: BaseSparseDbQueryParamsData):
        """Returns matches for given `query` from sparse Db"""
        raise NotImplementedError

    @abc.abstractmethod
    def delete_records(self):
        """Delete specific records from sparse dB"""
        raise NotImplementedError
