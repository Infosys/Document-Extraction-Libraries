# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from typing import Optional
try:
    from pydantic.v1 import BaseModel
except ImportError:
    from pydantic import BaseModel


class BaseSparseDbConfigData(BaseModel):
    """Base class for Sparse provider config data"""
    db_folder_path: str
    db_index_name: str
    db_index_secret_key: Optional[str] = None


class BaseSparseDbSaveRecordData(BaseModel):
    """Base class for storing records to Sparse DB"""
    content_file_path: str
    metadata: dict = None


class BaseSparseDbRecordData(BaseModel):
    """Base class for storing records to Sparse DB"""
    content: str = None
    metadata: dict = None


class BaseSparseDbQueryParamsData(BaseModel):
    """Base class for storing query params for Sparse DB"""
    query: str = None
    top_k: int
    pre_filter_fetch_k: int
    filter_metadata: dict = None


class BaseSparseDbMacthesData(BaseModel):
    """Base class for fetching mathes from Sparse DB search"""
    db_folder_path: str = None
    content: str = None
    metadata: dict = None
    score: float = None


class OnlineSparseDbConfigData(BaseModel):
    """Base class for online provider config data"""
    db_service_url: str = None
    method_name: str = None
    index_id: Optional[str] = None
    collection_name: str = None
    collection_secret_key: str = None
