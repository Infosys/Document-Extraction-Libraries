# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for Sentence Transformer embedding provider class"""

import requests
from ....embedding.interface.i_embedding_provider import IEmbeddingProvider
from ....schema.config_data import BaseEmbeddingProviderConfigData
from ....schema.embedding_data import EmbeddingData


class StEmbeddingProviderConfigData(BaseEmbeddingProviderConfigData):
    """Domain class"""


class StEmbeddingProvider(IEmbeddingProvider):
    """Sentence Transformer embedding provider"""

    def __init__(self, config_data: StEmbeddingProviderConfigData) -> None:
        base_url = config_data.api_url.rstrip('/')
        self.base_url = f"{base_url}/api/v1/model/embedding/generate"
        # self.model_name = config_data.model_name

    def generate_embedding(self, text: str) -> EmbeddingData:
        response_obj = requests.post(
            self.base_url,
            json=text,
            timeout=300
        )
        embedding_dict = response_obj.json()
        text_embeddings = embedding_dict.get('vector', [])
        vector = self.convert_to_numpy_array(text_embeddings)
        embedding_data = EmbeddingData(vector=vector,
                                       vector_dimension=embedding_dict.get(
                                           'vector_dimension'),
                                       error_message=embedding_dict.get(
                                           'error_message'),
                                       model_name=embedding_dict.get(
                                           'model_name')
                                       )
        return embedding_data
