# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import json
import logging
from typing import List
import requests

import infy_fs_utils
from ....common.singleton import Singleton
from ....common import Constants


class CustomService(metaclass=Singleton):
    """Wrapper class for Custom Embedding Provider"""

    def __init__(self, api_key: str, endpoint: str = None) -> None:
        if not endpoint:
            raise ValueError(
                'Endpoint should be provided')
        self.__api_key = api_key
        self.__endpoint = endpoint

    def generate_embedding(self, text) -> dict:
        """Generate embedding for given text using Custom Embedding Provider"""
        if self.__endpoint:
            result = self.__call_remote(text)
        return result

    def __call_remote(self, text: str) -> List[float]:
        if infy_fs_utils.manager.FileSystemLoggingManager().has_fs_logging_handler():
            __logger = infy_fs_utils.manager.FileSystemLoggingManager(
            ).get_fs_logging_handler().get_logger()
        else:
            __logger = logging.getLogger(__name__)

        result = {
            'embedding': [],
            'size': 0,
            'error_message': None
        }

        headers = {
            'Content-Type': 'application/json',
        }

        data_raw = {
            'inputs': [text]
        }
        try:
            response = requests.post(
                self.__endpoint, headers=headers, json=data_raw, timeout=120, verify=False)
            if response.status_code == 200:
                content = json.loads(response.content.decode("utf-8"))
                result['embedding'] = content[0]
                result['size'] = len(content[0])
            else:
                message = f'Error in calling API {response.status_code}'
                result['error_message'] = message
                __logger.error(message)
        except Exception as ex:
            message = f'Error occurred while calling API. Error: {str(ex)}'
            result['error_message'] = message
            __logger.exception(message)
        return result
