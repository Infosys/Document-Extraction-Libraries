# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for OpenAI embedding provider class"""

import os
import litellm
from ....schema.config_data import BaseEmbeddingProviderConfigData
from ....embedding.interface.i_embedding_provider import IEmbeddingProvider
from ....schema.embedding_data import EmbeddingData


class OpenAIFormatEmbeddingProviderConfigData(BaseEmbeddingProviderConfigData):
    """Domain class"""
    api_url: str
    api_key: str
    model_name: str
    api_version: str


class OpenAIFormatEmbeddingProvider(IEmbeddingProvider):
    """OpenAI embedding provider"""

    def __init__(self, config_data: OpenAIFormatEmbeddingProviderConfigData) -> None:
        self.config_data = config_data
        self.api_base = self.config_data.api_url
        self.api_key = self.config_data.api_key
        self.model_name = self.config_data.model_name
        self.api_version = self.config_data.api_version
        super().__init__()

    def generate_embedding(self, text: str) -> EmbeddingData:
        os.environ["AZURE_API_KEY"] = self.api_key

        response = litellm.embedding(
            api_base=self.api_base,
            api_key=self.api_key,
            model=self.model_name,
            api_version=self.api_version,
            input=[text],
            timeout=120)

        response_dict = response.json()
        text_embeddings = response_dict['data'][0].get('embedding')
        vector = self.convert_to_numpy_array(text_embeddings)
        embedding_data = EmbeddingData(vector=vector,
                                       vector_dimension=len(text_embeddings),
                                       error_message=None,
                                       model_name=self.config_data.model_name)
        return embedding_data
