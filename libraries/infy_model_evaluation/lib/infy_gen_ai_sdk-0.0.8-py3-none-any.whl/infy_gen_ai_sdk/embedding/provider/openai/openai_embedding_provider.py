# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for OpenAI embedding provider class"""

from deprecated import deprecated
from ....schema.config_data import BaseEmbeddingProviderConfigData
from ....embedding.interface.i_embedding_provider import IEmbeddingProvider
from .openai_service import OpenAIService
from ....schema.embedding_data import EmbeddingData


@deprecated(version='0.0.8', reason="This class is deprecated. Please use new class OpenAIFormatEmbeddingProviderConfigData.")
class OpenAIEmbeddingProviderConfigData(BaseEmbeddingProviderConfigData):
    """Domain class"""
    api_key: str
    api_version: str
    api_type: str
    api_url: str
    chunk_size: int
    model_name: str
    deployment_name: str


@deprecated(version='0.0.8', reason="This class is deprecated. Please use new class OpenAIFormatEmbeddingProvider.")
class OpenAIEmbeddingProvider(IEmbeddingProvider):
    """OpenAI embedding provider"""

    def __init__(self, config_data: OpenAIEmbeddingProviderConfigData) -> None:
        self.__embeddings = OpenAIService(model_name=config_data.model_name,
                                          api_key=config_data.api_key, api_base=config_data.api_url,
                                          api_version=config_data.api_version)
        self.__config_data = config_data
        super().__init__()

    def generate_embedding(self, text: str) -> EmbeddingData:
        text_embeddings = self.__embeddings.embed_query(text)
        vector = self.convert_to_numpy_array(text_embeddings)
        embedding_data = EmbeddingData(vector=vector,
                                       vector_dimension=len(text_embeddings),
                                       error_message=None,
                                       model_name=self.__config_data.model_name)
        return embedding_data
