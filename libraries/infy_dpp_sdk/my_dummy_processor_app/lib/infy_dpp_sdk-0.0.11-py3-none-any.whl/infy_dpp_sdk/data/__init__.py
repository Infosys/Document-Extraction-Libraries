# ===============================================================================================================#
# (C) 2022 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import pydantic

if pydantic.__version__.startswith("1."):
    from ._v1.document_data import DocumentData
    from ._v1.message_data import MessageData
    from ._v1.message_item_data import (
        MessageItemData, MessageTypeEnum, MessageCodeEnum)
    from ._v1.meta_data import MetaData
    from ._v1.page_data import PageData
    from ._v1.processor_response_data import ProcessorResponseData
    from ._v1.standard_data import StandardData
    from ._v1.value_data import ValueData
    from ._v1.extracted_data import ExtractedData
    from ._v1.text_data import TextData
    from ._v1.raw_data import (RawData, TableData, Table, CellData,
                               KeyValueData, ClassData, ContentData)
    from ._v1.config_data import ConfigData
    from ._v1.controller_req_res_data import (ControllerRequestData, ControllerResponseData,
                                              SnapshotData, RecordData, ProcessorFilterData)
else:
    from .document_data import DocumentData
    from .message_data import MessageData
    from .message_item_data import (
        MessageItemData, MessageTypeEnum, MessageCodeEnum)
    from .meta_data import MetaData
    from .page_data import PageData
    from .processor_response_data import ProcessorResponseData
    from .standard_data import StandardData
    from .value_data import ValueData
    from .extracted_data import ExtractedData
    from .text_data import TextData
    from .raw_data import (RawData, TableData, Table, CellData,
                           KeyValueData, ClassData, ContentData)
    from .config_data import ConfigData
    from .controller_req_res_data import (ControllerRequestData, ControllerResponseData,
                                          SnapshotData, RecordData, ProcessorFilterData)
