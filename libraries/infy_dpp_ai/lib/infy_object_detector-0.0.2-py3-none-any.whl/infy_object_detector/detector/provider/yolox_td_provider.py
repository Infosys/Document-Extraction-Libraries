# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import logging
import infy_fs_utils
import unstructured_inference.models.base as models
from unstructured_inference.inference.layout import DocumentLayout
from unstructured_inference.models.yolox import UnstructuredYoloXModel, MODEL_TYPES, YOLOX_LABEL_MAP
from unstructured_inference.utils import (
    LazyDict,
    LazyEvaluateInfo,
    download_if_needed_and_get_local_path,
)
from ..interface.i_table_detector_provider import ITableDetectorProvider
from ...schema.table_data import BaseTableConfigData, BaseTableRequestData, BaseTableResponseData


class YoloxTdProviderConfigData(BaseTableConfigData):
    """Yolox table provider config data class"""


class YoloxTdRequestData(BaseTableRequestData):
    """Yolox table request data class"""


class YoloxTdResponseData(BaseTableResponseData):
    """Yolox table response data class"""
    image_width: int = None
    image_height: int = None


class YoloxTdProvider(ITableDetectorProvider):
    """Yolox table provider class"""

    def __init__(self, config_data: YoloxTdProviderConfigData) -> None:
        if infy_fs_utils.manager.FileSystemLoggingManager().has_fs_logging_handler():
            self.__logger = infy_fs_utils.manager.FileSystemLoggingManager(
            ).get_fs_logging_handler().get_logger()
        else:
            self.__logger = logging.getLogger(__name__)

        self.__fs_handler = infy_fs_utils.manager.FileSystemManager(
        ).get_fs_handler()
        self.__model_path = config_data.model_path
        self.__model_name = config_data.model_name
        if self.__model_name not in MODEL_TYPES:
            self.__register_local_model()
        self.__model = self.__get_model()

    def detect_table(self, request_data: YoloxTdRequestData) -> YoloxTdResponseData:
        """Detect Table for the provided image"""
        td_response = self.__call_model(
            request_data.image_file_path)
        return td_response

    def __call_model(self, image_file_path: str) -> YoloxTdResponseData:
        layout = DocumentLayout.from_image_file(
            image_file_path, detection_model=self.__model)
        elements_list = []
        image_width = None
        image_height = None
        layout_elements = layout.pages[0].elements

        for element in layout_elements:
            if element.type == "Table":
                data = {
                    "bbox": [round(element.bbox.x1, 2),
                             round(element.bbox.y1, 2),
                             round(element.bbox.x2, 2),
                             round(element.bbox.y2, 2)],
                    "td_confidence_pct": round(element.prob, 3)

                }
                elements_list.append(data)
        if elements_list:
            image_width = layout.pages[0].image_metadata["width"]
            image_height = layout.pages[0].image_metadata["height"]

        return YoloxTdResponseData(image_width=image_width, image_height=image_height, table_data=elements_list)

    def __register_local_model(self):
        local_model_path = LazyEvaluateInfo(
            download_if_needed_and_get_local_path,
            self.__model_path,
            "yolox_l0.05.onnx",
        )
        model_type = {
            self.__model_name: LazyDict(
                model_path=local_model_path,
                label_map=YOLOX_LABEL_MAP,
            )
        }
        models.register_new_model(model_type, UnstructuredYoloXModel)

    def __get_model(self):
        return models.get_model(self.__model_name)
