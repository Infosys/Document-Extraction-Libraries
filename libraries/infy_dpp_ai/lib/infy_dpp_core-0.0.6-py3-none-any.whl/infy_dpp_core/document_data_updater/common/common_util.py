# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import uuid
from importlib import import_module

class CommonUtil:

    @classmethod
    def get_uuid(cls):
        return str(uuid.uuid4())

    @classmethod
    def get_rule_class_instance(cls, rc_module_name: str, rc_entity_name: str = None):

        # rc_module_name = reduce(lambda x, y: x + ('_' if y.isupper()
        #                                           else '') + y, rc_module_name).lower()
        rc_name = "".join([str(x).title() for x in rc_module_name.split('_')])
        if rc_entity_name:
            rule_mudule = import_module(
                f"infy_dpp_core.document_data_updater.rules.{rc_entity_name}.{rc_module_name}")
        else:
            rule_mudule = import_module(f"infy_dpp_core.document_data_updater.rules.{rc_module_name}")
        rule_class = getattr(rule_mudule, rc_name)

        return rule_class