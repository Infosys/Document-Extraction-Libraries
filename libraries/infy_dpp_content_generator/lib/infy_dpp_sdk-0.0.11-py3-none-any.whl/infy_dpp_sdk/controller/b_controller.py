# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import json
from typing import List
import logging
import infy_fs_utils
from ..data import (ControllerRequestData,
                    ControllerResponseData, ProcessorResponseData)
from ..interface import IController
from ..common import Constants
from ..common.snapshot_util import SnapshotUtil


class BController(IController):
    """Base class for controller"""

    __fs_handler: infy_fs_utils.interface.IFileSystemHandler = None

    def __init__(self):
        super().__init__()
        self.__fs_handler = infy_fs_utils.manager.FileSystemManager(
        ).get_fs_handler(Constants.FSH_DPP)
        if infy_fs_utils.manager.FileSystemLoggingManager().has_fs_logging_handler(Constants.FSLH_DPP):
            self.__logger = infy_fs_utils.manager.FileSystemLoggingManager(
            ).get_fs_logging_handler(Constants.FSLH_DPP).get_logger()
        else:
            self.__logger = logging.getLogger(__name__)

    def do_execute_batch(self, controller_request_data: ControllerRequestData) -> ControllerResponseData:
        print("Executing BController...")
        return super().do_execute_batch(controller_request_data)

    def load_config_data(self, controller_request_data: ControllerRequestData) -> dict:
        input_config_file_path = controller_request_data.input_config_file_path
        input_config_data = self.__load_json(
            input_config_file_path)
        return input_config_data

    def load_snapshots(self, controller_request_data: ControllerRequestData):
        return SnapshotUtil().load_snapshots(controller_request_data)

    def save_snapshots(self, controller_request_data: ControllerRequestData,
                       processor_response_data_list: List[ProcessorResponseData]) \
            -> ControllerResponseData:
        return SnapshotUtil().save_snapshots(controller_request_data, processor_response_data_list)

    def _get_logger(self):
        return self.__logger

    # --------- Private Methods -------------
    def __load_json(self, file_path) -> any:
        data = json.loads(self.__fs_handler.read_file(
            file_path))
        return data
