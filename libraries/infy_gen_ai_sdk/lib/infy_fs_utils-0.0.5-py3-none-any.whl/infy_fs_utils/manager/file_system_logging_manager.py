# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module containing FileSystemLoggingManager"""

from typing import Dict
from .._common.singleton import Singleton
from ..interface.i_file_system_logging_handler import IFileSystemLoggingHandler


class FileSystemLoggingManager(metaclass=Singleton):
    """Factory class to get singleton logger object at application level"""

    __file_sys_logging_handler_dict: Dict[str,
                                          IFileSystemLoggingHandler] = None
    __root_handler_name = None

    def __init__(self) -> None:
        self.__file_sys_logging_handler_dict: {}

    def set_root_handler_name(self, name: str) -> None:
        """Sets the root handler name"""
        self.__root_handler_name = name

    def has_fs_logging_handler(self, name: str = 'default') -> bool:
        """Returns True if an instance of IFileSystemLoggingHandler exists"""
        _name = self.__root_handler_name if self.__root_handler_name else name
        if self.__file_sys_logging_handler_dict:
            return _name in self.__file_sys_logging_handler_dict.keys()
        return False

    def get_fs_logging_handler(self, name: str = 'default') -> IFileSystemLoggingHandler:
        """Returns an instance of IFileSystemLoggingHandler"""
        _name = self.__root_handler_name if self.__root_handler_name else name
        if self.__file_sys_logging_handler_dict:
            return self.__file_sys_logging_handler_dict.get(_name, None)
        return None

    def delete_fs_logging_handler(self, name: str = 'default') -> bool:
        """Deletes an instance of IFileSystemLoggingHandler"""
        _name = self.__root_handler_name if self.__root_handler_name else name
        if self.__file_sys_logging_handler_dict and self.__file_sys_logging_handler_dict.get(_name, None):
            obj: IFileSystemLoggingHandler = self.__file_sys_logging_handler_dict.pop(
                _name)
            obj.unset_handler()
            del obj
            return True
        return False

    def add_fs_logging_handler(self, file_sys_logging_handler: IFileSystemLoggingHandler,
                               name: str = 'default') -> None:
        """Adds an instance of IFileSystemLoggingHandler"""
        _name = self.__root_handler_name if self.__root_handler_name else name
        if not isinstance(file_sys_logging_handler, IFileSystemLoggingHandler):
            message = f"{file_sys_logging_handler} is not an instance of IFileSystemLoggingHandler."
            raise ValueError(message)
        existing_keys = []
        if self.__file_sys_logging_handler_dict:
            existing_keys = list(self.__file_sys_logging_handler_dict.keys())
            if _name in existing_keys:
                raise ValueError(
                    f"Duplicate key={_name} found. Please provide unique keys.")
            self.__file_sys_logging_handler_dict[_name] = file_sys_logging_handler
        else:
            self.__file_sys_logging_handler_dict = {
                _name: file_sys_logging_handler}

    def add_fs_logging_handlers(self, file_sys_logging_handler_dict: Dict[str, IFileSystemLoggingHandler]) -> None:
        """Adds one or more instances of IFileSystemLoggingHandler"""
        if file_sys_logging_handler_dict:
            for key, value in file_sys_logging_handler_dict.items():
                if not isinstance(value, IFileSystemLoggingHandler):
                    message = f"For key={key}, the value={value} is not an instance of IFileSystemLoggingHandler."
                    raise ValueError(message)
            if not self.__file_sys_logging_handler_dict:
                self.__file_sys_logging_handler_dict = file_sys_logging_handler_dict
                return
            existing_keys = list(self.__file_sys_logging_handler_dict.keys())
            new_keys = list(file_sys_logging_handler_dict.keys())
            duplicate_keys = [x for x in new_keys if x in existing_keys]
            if duplicate_keys:
                raise ValueError(
                    f"Duplicate keys={duplicate_keys} found. Please provide unique keys.")
            self.__file_sys_logging_handler_dict.update(
                file_sys_logging_handler_dict)
