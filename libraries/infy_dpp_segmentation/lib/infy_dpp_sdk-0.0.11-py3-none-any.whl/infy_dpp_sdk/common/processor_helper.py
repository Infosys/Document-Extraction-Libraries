# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for Processor Helper class"""
from ..data import (DocumentData, ProcessorResponseData, MessageData,
                    MessageItemData, MessageTypeEnum, MessageCodeEnum)


class ProcessorHelper():
    """Class for Processor Helper"""

    @classmethod
    def create_processor_response_data(cls, document_data: DocumentData,
                                       context_data: dict,
                                       exception: Exception) -> ProcessorResponseData:
        """Create Processor Response Data with exception"""
        message = f"UNHANDLED EXCEPTION => {exception}"
        message_data = MessageData()
        message_item_data = MessageItemData(
            message_type=MessageTypeEnum.ERROR,
            message_code=MessageCodeEnum.SERVER_ERR_UNHANDLED_EXCEPTION,
            message_text=message)
        message_data.messages.append(message_item_data)
        processor_response_data = ProcessorResponseData(
            document_data=document_data, context_data=context_data,
            message_data=message_data)
        return processor_response_data

    @classmethod
    def get_messages(cls, processor_response_data: ProcessorResponseData,
                     message_code_enum: MessageCodeEnum = None) -> list:
        """Get messages from Processor Response Data"""
        messages = []
        if processor_response_data.message_data and processor_response_data.message_data.messages:
            messages = processor_response_data.message_data.messages
            if message_code_enum:
                messages = [
                    x for x in messages if x.message_code == message_code_enum]
        return messages
