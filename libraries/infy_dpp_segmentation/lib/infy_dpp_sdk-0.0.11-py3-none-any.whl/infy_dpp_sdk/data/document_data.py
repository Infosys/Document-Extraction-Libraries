# ===============================================================================================================#
# (C) 2022 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import uuid
from typing import List
from pydantic import BaseModel, field_validator, Field
from ..data.meta_data import MetaData
from ..data.page_data import PageData
from ..data.raw_data import RawData
from ..data.text_data import TextData


class DocumentData(BaseModel):
    """Document Data class"""
    document_id: str | None = Field(default=None, validate_default=True)
    metadata: MetaData | None = None
    page_data: List[PageData] | None = None
    business_attribute_data: list | None = None
    text_data: List[TextData] | None = None
    raw_data: RawData | None = None

    @field_validator('document_id', mode='before')
    @classmethod
    def validate_document_id(cls, v):
        """Validate document_id"""
        if not v:
            return str(uuid.uuid4())
        else:
            return v
