# ===============================================================================================================#
# (C) 2021 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import datetime
import os
import shutil
from datetime import datetime


class CommonUtils:
    """Common util class"""

    @staticmethod
    def make_dir_with_timestamp(folderpath, img_name):
        timestr = datetime.now().strftime("%Y%m%d-%H%M%S")
        folderpath = os.path.join(
            folderpath, img_name+'_'+timestr)
        os.mkdir(folderpath)
        return folderpath

    @staticmethod
    def delete_dir_recursively(folderpath):
        shutil.rmtree(folderpath)

    @staticmethod
    def archive_file(original_file_path):
        if os.path.exists(original_file_path):
            ext = os.path.splitext(original_file_path)[1]
            suffix = datetime.now().strftime("%Y_%m_%d_%H_%M_%S") + ext
            new_name = f'{original_file_path.replace(ext,"")}_{suffix}'
            os.rename(original_file_path, new_name)
