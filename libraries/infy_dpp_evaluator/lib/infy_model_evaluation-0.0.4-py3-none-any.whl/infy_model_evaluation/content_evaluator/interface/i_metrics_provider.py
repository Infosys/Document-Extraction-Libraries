# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for embedding provider interface class"""

import abc
from typing import List
from ...data.content_evaluator_data import (
    ContentEvaluatorReqData, MetricsData)
from ...data.llm_data import LLMConfigData


class IMetricsProvider(metaclass=abc.ABCMeta):
    """Interface class for question answer generation provider"""

    def __init__(self, prompt_template_dict: dict):
        self.__prompt_template_dict = prompt_template_dict

    @abc.abstractmethod
    def calculate_metrics(self, content_evaluator_req_data: ContentEvaluatorReqData) -> MetricsData:
        """Evaluate the content and return the metrics based on model used"""
        raise NotImplementedError

    @abc.abstractmethod
    def set_llm_provider(self, llm_config_data_list: List[LLMConfigData]):
        """Set the LLM provider(s)"""
        raise NotImplementedError

    def get_prompt_template_dict(self) -> dict:
        """Get the prompt templates for the metrics"""
        # dict with name and prompt template content
        return self.__prompt_template_dict.copy()

    def set_prompt_template_dict(self, prompt_template_dict: dict):
        """Set the prompt templates for the metrics"""
        #  validation for extra keys in prompt_template_dict
        #  and raise exception if any extra key is present
        metrics_keys = set(self.__prompt_template_dict.keys())
        new_keys = set(prompt_template_dict.keys())
        if not new_keys.issubset(metrics_keys):
            print(f"ERROR: Invalid keys present in {prompt_template_dict}")
            raise Exception(f"Invalid keys present in {prompt_template_dict}")
        else:
            self.__prompt_template_dict.update(prompt_template_dict.copy())
