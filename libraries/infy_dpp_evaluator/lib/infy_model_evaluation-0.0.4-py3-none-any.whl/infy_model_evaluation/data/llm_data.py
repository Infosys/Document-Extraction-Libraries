# ===============================================================================================================#
# (C) 2022 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#
from typing import Dict, Any
try:
    from pydantic.v1 import BaseModel
except ImportError:
    from pydantic import BaseModel


class BaseLlmRequestData(BaseModel):
    """Base class for request to LLM"""
    prompt_template: str = None


class BaseLlmResponseData(BaseLlmRequestData):
    """Base class for response from LLM"""
    llm_request_txt: str = None
    llm_response_txt: str = None


class LLMProvidersData(BaseModel):
    llm_provider_obj: Any = None  # ILlmProvider
    llm_res_parser_obj: Any = None  # ILLMResponseParserProvider


class LLMConfigData(BaseModel):
    __root__: Dict[str, LLMProvidersData]
