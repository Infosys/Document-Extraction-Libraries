# ===============================================================================================================#
# (C) 2023 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

"""Module for LLM provider interface class"""


import abc
from ...data.llm_data import BaseLlmRequestData, BaseLlmResponseData


class ILlmProvider(metaclass=abc.ABCMeta):
    """Interface class for LLM provider"""

    def __init__(self, model_name: str) -> None:
        self._model_name = model_name

    @abc.abstractmethod
    def get_llm_response(self, llm_request_data: BaseLlmRequestData) -> BaseLlmResponseData:
        """Get response from LLM"""
        raise NotImplementedError

    def get_model_name(self) -> str:
        """Get the model name"""
        return self._model_name
