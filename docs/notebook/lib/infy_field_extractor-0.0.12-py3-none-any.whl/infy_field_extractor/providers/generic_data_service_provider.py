# ===============================================================================================================#
# Copyright 2021 Infosys Ltd.                                                                                   #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import os
import json
import urllib3
import logging
import numpy as np
from infy_ocr_parser import ocr_parser
from infy_field_extractor.interface.data_service_provider_interface import DataServiceProviderInterface, \
    FILE_DATA_LIST, ADDITIONAL_INFO, GET_TOKENS_OUTPUT, TEXT_MATCH_METHOD, BBOX, GET_BBOX_FOR_OUTPUT, TEXT


class GenericDataServiceProvider(DataServiceProviderInterface):
    """Tesseract Data Service Provider"""
    API_GET_TOKENS = "/api/v1/field/extractor/tokens"
    API_GET_BBOX = "/api/v1/field/extractor/bbox"
    API_POST_FILE_UPLOAD = "/api/v1/file/upload"

    def __init__(self, base_url: str, ocr_parser_object: ocr_parser.OcrParser,
                 logger: logging.Logger = None, log_level: int = None,
                 hocr_file_path: str = None):
        """Creates a Tesseract Data Service Provider

        Args:
            ocr_parser_object (ocr_parser.OcrParser): ocr parser
            base_url:base_url for api call
            logger (logging.Logger, optional): Logger object. Defaults to None.
            log_level (int, optional): Logging Level. Defaults to None.
            hocr_file_path : HOCR file path.Defaults to None.
        Raises:
            Exception: Raises an error if property ocr_parser_object not found
            Exception: Raises an error if ocr_parser_object is invalid
        """
        super(GenericDataServiceProvider, self).__init__(logger, log_level)
        # validate ocr_parser_object
        self.ocr_parser_object = ocr_parser_object
        self._base_url = base_url
        self._http = self.__get_http_handle()
        self._hocr_file_path = hocr_file_path
        self._file_id = ''
        if ocr_parser_object is None:
            raise Exception("property ocr_parser_object not found")
        elif not isinstance(ocr_parser_object, ocr_parser.OcrParser):
            raise Exception("Provide valid ocr_parser_object")

    def get_tokens(
            self, token_type_value: int, img: np.array, text_bbox: BBOX,
            file_data_list: FILE_DATA_LIST = None,
            additional_info: ADDITIONAL_INFO = None,
            temp_folderpath: str = None) -> GET_TOKENS_OUTPUT:
        """Method to return the text from the
            image from the text_bbox as a list of dictionary.

        Args:
            token_type_value (int): Type of text to be returned.
            img (np.array): Read image as np array of the original image.
            text_bbox (BBOX): Text bbox
            file_data_list (FILE_DATA_LIST, optional): List of all file datas.
                Each file data has the path to supporting document and page numbers, if applicable.
                When multiple files are passed, provider has to pick the right file
                based on the image dimensions or type of file extension.
                Defaults to None.
            additional_info (ADDITIONAL_INFO, optional): Additional info. Defaults to None.
            temp_folderpath (str, optional): Path to temp folder. Defaults to None.

        Returns:
            GET_TOKENS_OUTPUT: list of dict containing text and its bbox.
        """
        #----------------- to upload hocr file api call----------------#
        with open(self._hocr_file_path, "rb") as reader:
            image_data = reader.read()
        api_url = self._base_url+GenericDataServiceProvider.API_POST_FILE_UPLOAD
        http = self._http
        response = http.request(
            "post", api_url,
            fields={
                'file1': (os.path.basename(self._hocr_file_path), image_data),
            }
        )
        self._file_id = json.loads(
            response.data.decode('utf-8'))['response']['file_id']
        #---------------------------gettoken API call----------------#
        bboxes_text = []
        json_input = {
            "file_id": self._file_id,
            "token_type_value": token_type_value,
            # "img": img,
            "text_bbox": text_bbox,
            # "file_data_list": file_data_list,
            "additional_info": additional_info
            # "temp_folderpath": temp_folderpath
        }
        api_url = self._base_url + GenericDataServiceProvider.API_GET_TOKENS
        data_input = json.dumps(json_input)

        headers = {
            'Content-Type': 'application/json'
        }

        response = self._http.request(
            "post", api_url,
            body=data_input,
            headers=headers)

        bboxes_text = json.loads(response.data.decode('utf-8'))['response']

        return bboxes_text

    def get_bbox_for(self, img: np.array, text: TEXT,
                     text_match_method: TEXT_MATCH_METHOD,
                     file_data_list: FILE_DATA_LIST = None,
                     additional_info: ADDITIONAL_INFO = None,
                     temp_folderpath: str = None) -> GET_BBOX_FOR_OUTPUT:
        """Method to return the text from the
        image from the text_bbox as a list of dictionary.

        Args:
            img (np.array): Read image as np array of the original images
            text (TEXT): Text
            text_match_method (TEXT_MATCH_METHOD): Method (`normal` or `regex`) used to match the text.
            file_data_list (FILE_DATA_LIST, optional): List of all file datas. Each file data has the path to
                supporting document and page numbers, if applicable.
                When multiple files are passed, provider has to pick the right file
                based on the image dimensions or type of file extension. Defaults to None.
            additional_info (ADDITIONAL_INFO, optional): Additional info. Defaults to None.
            temp_folderpath (str, optional): Path to temp folder. Defaults to None.

        Returns:
            BBOX: list of dict containing text and its bbox.
        """
        ocr_parser_get_bbox_for_list = []
        data_input = {
            "file_id": self._file_id,
            "text": text,
            "text_match_method": text_match_method,
            "additional_info": additional_info
        }
        api_url = self._base_url + GenericDataServiceProvider.API_GET_BBOX
        json_input = json.dumps(data_input)

        headers = {
            'Content-Type': 'application/json'
        }

        response = self._http.request(
            "post", api_url,
            body=json_input,
            headers=headers)

        ocr_parser_get_bbox_for_list = json.loads(
            response.data.decode('utf-8'))['response']

        return ocr_parser_get_bbox_for_list

    def __get_http_handle(self):
        http_proxy_url = os.environ.get("OCR_GEN_HTTP_PROXY_URL")
        http_proxy_auth = os.environ.get("OCR_GEN_HTTP_PROXY_AUTH")
        http = None
        if http_proxy_url:
            if http_proxy_auth:
                auth_header = {
                    'proxy-authorization': f'Basic {http_proxy_auth}'}
                http = urllib3.ProxyManager(
                    http_proxy_url, cert_reqs='CERT_NONE', proxy_headers=auth_header)
            else:
                http = urllib3.ProxyManager(
                    http_proxy_url, cert_reqs='CERT_NONE')
        else:
            http = urllib3.PoolManager()
        return http
