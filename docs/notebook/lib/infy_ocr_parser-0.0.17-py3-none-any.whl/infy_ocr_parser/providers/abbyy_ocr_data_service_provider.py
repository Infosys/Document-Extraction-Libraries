# ===============================================================================================================#
# (C) 2020 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

import copy
import logging

import bs4
from infy_ocr_parser.interface.data_service_provider_interface import \
    DataServiceProviderInterface
from infy_ocr_parser._internal.response import Response


class AbbyyOcrDataServiceProvider(DataServiceProviderInterface):
    """Implementation of DataServiceProvider for Abbyy OCR"""

    def __init__(self, logger: logging.Logger = None,
                 log_level: int = None):
        super(AbbyyOcrDataServiceProvider,
              self).__init__(logger, log_level)
        self._ocr_file_data_list = []

    def init_provider_inputs(self, doc_list: list):
        if doc_list:
            self._ocr_file_data_list = []
        for ocr_file in doc_list:
            with open(ocr_file, 'r', encoding='utf8') as file_reder:
                self._ocr_file_data_list.append(file_reder.read())

    def get_line_dict_from(self, pages: list = None,
                           line_dict_list: list = None, scaling_factors: list = None) -> list:
        if not scaling_factors:
            scaling_factors = [1.0, 1.0]
        try:
            lines_structure = []
            if line_dict_list:
                if len(pages) == 0:
                    return line_dict_list
                else:
                    _ = [lines_structure.append(
                        ocr_line_obj) for ocr_line_obj in line_dict_list if ocr_line_obj["page"] in pages]
                    return lines_structure
            for _, xml_file in enumerate(self._ocr_file_data_list):
                soup = bs4.BeautifulSoup(xml_file, 'lxml')
                page_obj_list = soup.findAll("page")
                for idx, page_obj in enumerate(page_obj_list):
                    page_no = idx+1
                    if len(pages) > 0 and page_no not in pages:
                        continue
                    line_obj = page_obj.findAll("line")
                    for _, line in enumerate(line_obj):
                        word_structure = self.__get_word_dict_from(
                            line, [page_no], scaling_factors=scaling_factors)
                        line_text_list = [word_struct["text"]
                                          for word_struct in word_structure]
                        # The coordinates of the bounding box
                        l, t, r, b = int(line["l"]), int(
                            line["t"]), int(line["r"]), int(line["b"])
                        w, h = r-l, b-t
                        lines_structure.append(
                            Response.data_dict(
                                f"line_{page_no}_{l}_{t}_{r}_{b}",
                                page_no,
                                " ".join(line_text_list),
                                [l, t, w, h],
                                f'{scaling_factors[0]}_{scaling_factors[1]}',
                                word_structure=word_structure
                            ))
            return lines_structure
        except Exception as e:
            raise Exception(e)

    def get_word_dict_from(self, pages: list = None,
                           word_dict_list: list = None, scaling_factors: list = None) -> list:
        return self.__get_word_dict_from(
            pages=pages, word_dict_list=word_dict_list, scaling_factors=scaling_factors)

    def __get_word_dict_from(self, line_obj=None, pages: list = None,
                             word_dict_list: list = None, scaling_factors: list = None) -> list:
        word_structure = []
        if not scaling_factors:
            scaling_factors = [1.0, 1.0]
        if line_obj:
            return self.__get_word_dict_from_soup(line_obj, pages[0], scaling_factors)

        if word_dict_list:
            if len(pages) == 0:
                return word_dict_list
            else:
                _ = [word_structure.append(
                    ocr_word_obj) for ocr_word_obj in word_dict_list if ocr_word_obj["page"] in pages]
                return word_structure

        for _, ocr in enumerate(self._ocr_file_data_list):
            soup = bs4.BeautifulSoup(ocr, 'lxml')
            page_obj_list = soup.findAll("page")
            for idx, page_obj in enumerate(page_obj_list):
                page_no = idx+1
                if len(pages) > 0 and page_no not in pages:
                    continue
                line_obj_list = page_obj.findAll("line")
                for line_obj in line_obj_list:
                    word_structure += self.__get_word_dict_from_soup(
                        line_obj, page_no, scaling_factors)
        return word_structure

    def get_page_bbox_dict(self) -> list:
        page_bbox_dict_list = []
        for _, ocr_file in enumerate(self._ocr_file_data_list):
            soup = bs4.BeautifulSoup(ocr_file, 'lxml')
            page_obj_list = soup.findAll("page")
            for idx, page_obj in enumerate(page_obj_list):
                bbox_tmp = [0, 0, int(page_obj["width"]),
                            int(page_obj["height"])]
                page_no_tmp = idx+1
                page_bbox_dict_list.append(
                    {"bbox": bbox_tmp, "page": page_no_tmp})
        return page_bbox_dict_list

    def __get_word_dict_from_soup(self, soup_obj, page_idx, scaling_factors) -> list:
        word_structure = []
        cParams = soup_obj.findAll("charparams")
        char_structure = []
        for idx_1, char in enumerate(cParams):
            cp_char_content = copy.copy(char.contents)
            char_idx = len(cp_char_content)-1
            isEmpty = True
            content = " "
            if char_idx > -1:
                c_text = cp_char_content[char_idx]
                content = c_text.replace(
                    "\n", " ") if c_text == "\n" else c_text.replace("\n", "")
                content = content.replace("\t", "")
                c_conf = int(char["charconfidence"]
                             ) if "charconfidence" in char.attrs else 0
                isEmpty = (content.strip() == "")
            if not isEmpty:
                char_structure.append(Response.data_dict(0, page_idx, content, [int(
                    char["l"]), int(char["t"]), int(char["r"]), int(char["b"])], conf=c_conf))

            if len(char_structure) > 0 and ((idx_1+1 == len(cParams)) or (isEmpty and (int(cParams[idx_1+1].get("wordstart", 0)) == 1 or int(cParams[idx_1+1].get("wordfirst", 0)) == 1))):
                text = ""
                t_conf = 0
                left_list, top_list, right_list, bottom_list = [], [], [], []
                for char_struct in char_structure:
                    text += char_struct["text"]
                    t_conf += int(char_struct["conf"])
                    left_list.append(char_struct["bbox"][0])
                    top_list.append(char_struct["bbox"][1])
                    right_list.append(char_struct["bbox"][2])
                    bottom_list.append(char_struct["bbox"][3])
                    t_conf = int(t_conf/len(char_structure))
                l, t, r, b = (min(left_list), min(top_list),
                              max(right_list), max(bottom_list))
                w, h = r-l, b-t
                word_structure.append(
                    Response.data_dict(
                        f"word_{page_idx}_{l}_{t}_{r}_{b}",
                        page_idx,
                        text,
                        [l, t, w, h],
                        f'{scaling_factors[0]}_{scaling_factors[1]}',
                        t_conf
                    )
                )
                char_structure = []

        return word_structure
