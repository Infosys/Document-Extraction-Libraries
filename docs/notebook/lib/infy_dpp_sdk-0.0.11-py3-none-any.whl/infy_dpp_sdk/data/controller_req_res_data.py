# ===============================================================================================================#
# (C) 2022 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 2.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from typing import List
from pydantic import BaseModel, model_validator, ConfigDict, Field


class SnapshotData(BaseModel):
    """Snapshot data class"""
    document_data_file_path: str | None = None
    context_data_file_path: str | None = None
    message_data_file_path: str | None = None

    model_config = ConfigDict(extra='forbid')


class ProcessorFilterData(BaseModel):
    """Processor filter data class"""
    includes: List[str] = []
    excludes: List[str] = []

    model_config = ConfigDict(extra='forbid')

    @model_validator(mode='before')
    @classmethod
    def check(cls, values):
        """Validate filter"""
        if values.get('includes') and values.get('excludes'):
            raise ValueError(
                'Specify either includes OR excludes but NOT both')
        return values


class RecordData(BaseModel):
    """Record data class"""
    document_id: str | None = None
    snapshot: SnapshotData | None = None

    model_config = ConfigDict(extra='forbid')


class ControllerRequestData(BaseModel):
    """Controller request data class"""
    dpp_version: str | None = None
    request_id: str | None = None
    description: str | None = None
    input_config_file_path: str | None = None
    processor_filter: ProcessorFilterData | None = None
    context: dict | None = None
    snapshot_dir_root_path: str | None = None
    records: List[RecordData] | None = Field(default=None)

    model_config = ConfigDict(extra='forbid')

    @model_validator(mode='before')
    @classmethod
    def check(cls, values):
        """Validate filter"""
        if values.get('context'):
            count = len(values.get('context').keys())
            if count > 1:
                raise ValueError(
                    f'Context should have only 1 root key. Found {count} keys')
        return values


class ControllerResponseData(ControllerRequestData):
    """Controller response data class"""
    model_config = ConfigDict(extra='forbid')
