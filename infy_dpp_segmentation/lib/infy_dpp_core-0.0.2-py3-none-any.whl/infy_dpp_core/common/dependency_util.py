class DependencyUtil:
    
    @classmethod
    def is_module_installed(cls, module_name):
        try:
            __import__(module_name)
        except ModuleNotFoundError:
            raise Exception(f"{module_name} is not installed.")
